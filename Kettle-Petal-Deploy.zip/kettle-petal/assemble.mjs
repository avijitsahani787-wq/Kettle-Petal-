// One offline build step for the dashboard upload. No API credentials or network input.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {dirname} from 'node:path';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const cakes='bento-bloom berry-layers birthday-cake caramel-bento chocolate-truffle cocoa-cupcakes cupcake-posies floral-wedding kesar-rasmalai lemon-silk midnight-forest pistachio-rose ruby-velvet silk-pearl-tiers strawberry-portrait vintage-heart'.split(' ');
const paths=['index.html','app.js','catalog.js','styles.css','preview-mode.js','assets/mark.svg','share/kettle-petal-lake-town.jpg','licenses/Cormorant-Garamond-OFL.txt','licenses/DM-Sans-OFL.txt',...['display-italic','display-regular','sans-regular'].map(k=>'assets/fonts/'+k+'.woff2'),...['bespoke-banner','strawberry-hero','pistachio-editorial',...cakes.flatMap(k=>['','-small','-card','-detail'].map(x=>k+x))].map(k=>'assets/images/'+k+'.webp')].sort();
const rows=await Promise.all(paths.map(async p=>[p,await readFile(p)]));
if(rows.length!==79||sha(rows.map(([p,b])=>p+' '+sha(b)+'\n').join(''))!=='1fb8e511fc1b64df0a44fd3bdefd0d9fbfb618054399f8d6b9cb2f9586a03893')throw Error('Incomplete or altered Kettle Petal release');
for(const [p,b] of rows){const dst='public/'+p;await mkdir(dirname(dst),{recursive:true});await writeFile(dst,b);}
console.log('Kettle Petal: 79 public files ready.');

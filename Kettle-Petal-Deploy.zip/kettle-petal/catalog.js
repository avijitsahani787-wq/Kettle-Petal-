/* One editorial menu powers the counter, finder, tasting notes, saved cakes and order briefs.
   Prices are indicative INR. Stable IDs and variant positions preserve existing bags. */
window.ATELIER = (() => {
  const image = name => 'assets/images/' + name + '.webp';
  const categories = [
  {
    "id": "birthday",
    "name": "Birthday Cakes",
    "image": "birthday-cake-small",
    "alt": "A vanilla birthday cake with slender rose and ivory candles"
  },
  {
    "id": "wedding",
    "name": "Wedding Cakes",
    "image": "floral-wedding-small",
    "alt": "A two-tier ivory wedding cake with peach garden roses"
  },
  {
    "id": "anniversary",
    "name": "Anniversary Cakes",
    "image": "vintage-heart-small",
    "alt": "A pink heart-shaped cake finished with vintage piping and cherries"
  },
  {
    "id": "bento",
    "name": "Bento Cakes",
    "image": "bento-bloom-small",
    "alt": "A small lilac bento cake decorated with buttercream daisies"
  },
  {
    "id": "cupcake",
    "name": "Cupcakes",
    "image": "cupcake-posies-small",
    "alt": "Three rose and vanilla buttercream cupcakes"
  },
  {
    "id": "signature",
    "name": "Signature Cakes",
    "image": "chocolate-truffle-small",
    "alt": "A dark chocolate cake crowned with ganache curls and hazelnuts"
  }
];
  const products = [
  {
    "id": "strawberry-chantilly",
    "name": "Strawberry Chantilly",
    "flavour": "Fresh berries · Vanilla cream",
    "description": "Soft vanilla sponge, strawberry filling, and clouds of whipped cream. Finished with piped swags and a little crown of seasonal berries.",
    "image": "strawberry-portrait",
    "alt": "Strawberry and raspberry Chantilly cake on a fluted porcelain pedestal",
    "categories": [
      "birthday",
      "signature",
      "anniversary"
    ],
    "badge": "Studio favourite",
    "cocoa": false,
    "variants": [
      [
        "½ kg",
        1450,
        "4–6 servings"
      ],
      [
        "1 kg",
        2550,
        "8–12 servings"
      ],
      [
        "1½ kg",
        3650,
        "12–18 servings"
      ]
    ],
    "families": [
      "fruit",
      "classic"
    ],
    "layers": [
      "Vanilla sponge",
      "Strawberry filling",
      "Whipped cream & seasonal berries"
    ],
    "tones": [
      "#d6b684",
      "#b64c61",
      "#f3d4c9"
    ],
    "edition": "signature",
    "folio": "01"
  },
  {
    "id": "chocolate-noir",
    "name": "Chocolate Noir",
    "flavour": "Dark chocolate · Hazelnut",
    "description": "Rich chocolate sponge wrapped in dark ganache, with hand-curled chocolate and toasted hazelnuts. Deep cocoa flavour in every forkful.",
    "image": "chocolate-truffle",
    "alt": "Dark chocolate truffle cake with chocolate curls and toasted hazelnuts",
    "categories": [
      "signature",
      "birthday"
    ],
    "badge": "",
    "cocoa": true,
    "variants": [
      [
        "½ kg",
        1250,
        "4–6 servings"
      ],
      [
        "1 kg",
        2250,
        "8–12 servings"
      ],
      [
        "1½ kg",
        3250,
        "12–18 servings"
      ]
    ],
    "families": [
      "chocolate",
      "nuts"
    ],
    "layers": [
      "Dark cocoa sponge",
      "Chocolate ganache",
      "Cocoa curls & toasted hazelnuts"
    ],
    "tones": [
      "#573d32",
      "#80513e",
      "#51382d"
    ],
    "edition": "signature",
    "folio": "02"
  },
  {
    "id": "cherry-ribbon",
    "name": "Cherry Ribbon Heart",
    "flavour": "Cherry · Vanilla buttercream",
    "description": "A love letter in buttercream: a heart-shaped vanilla cake, cherry filling, delicate pink ruffles, and glossy cherries with their stems still on.",
    "image": "vintage-heart",
    "alt": "Vintage pink heart cake edged in piped buttercream with red cherries",
    "categories": [
      "anniversary",
      "birthday",
      "signature"
    ],
    "badge": "Vintage edit",
    "cocoa": false,
    "variants": [
      [
        "½ kg",
        1350,
        "4–6 servings"
      ],
      [
        "1 kg",
        2450,
        "8–12 servings"
      ],
      [
        "1½ kg",
        3550,
        "12–18 servings"
      ]
    ],
    "families": [
      "fruit",
      "classic"
    ],
    "layers": [
      "Vanilla sponge",
      "Cherry filling",
      "Ruffled pink buttercream"
    ],
    "tones": [
      "#dfbf91",
      "#a23e56",
      "#e4a5b4"
    ],
    "edition": "signature",
    "folio": "03"
  },
  {
    "id": "berry-cloud",
    "name": "The Berry Layer Cake",
    "flavour": "Berry compote · Vanilla sponge",
    "description": "Golden layers of vanilla sponge, soft cream, and bright berry compote, left beautifully uncovered. A generous tumble of fresh fruit finishes the top.",
    "image": "berry-layers",
    "alt": "Three-layer vanilla sponge cake with cream, raspberries and blueberries",
    "categories": [
      "signature",
      "birthday",
      "anniversary"
    ],
    "badge": "",
    "cocoa": false,
    "variants": [
      [
        "½ kg",
        1550,
        "4–6 servings"
      ],
      [
        "1 kg",
        2750,
        "8–12 servings"
      ],
      [
        "1½ kg",
        3950,
        "12–18 servings"
      ]
    ],
    "families": [
      "fruit"
    ],
    "layers": [
      "Golden vanilla sponge",
      "Berry compote & cream",
      "A tumble of mixed berries"
    ],
    "tones": [
      "#d8b781",
      "#bd5366",
      "#ecdcbd"
    ],
    "edition": "signature",
    "folio": "04"
  },
  {
    "id": "birthday-wish",
    "name": "The Birthday Wish",
    "flavour": "Vanilla bean · Buttercream",
    "description": "A candlelit classic with vanilla sponge, softly ridged buttercream, and a scattering of confetti sprinkles. A sweet canvas for a birthday wish.",
    "image": "birthday-cake",
    "alt": "A vanilla birthday cake with slender rose and ivory candles",
    "categories": [
      "birthday"
    ],
    "badge": "Celebration edit",
    "cocoa": false,
    "variants": [
      [
        "½ kg",
        1150,
        "4–6 servings"
      ],
      [
        "1 kg",
        2050,
        "8–12 servings"
      ],
      [
        "1½ kg",
        2950,
        "12–18 servings"
      ]
    ],
    "families": [
      "classic"
    ],
    "layers": [
      "Vanilla bean sponge",
      "Vanilla buttercream",
      "Pastel shells & confetti sprinkles"
    ],
    "tones": [
      "#dfbd8d",
      "#efd5be",
      "#e6b1ad"
    ],
    "edition": "signature",
    "folio": "05"
  },
  {
    "id": "garden-vows",
    "name": "Garden Vows",
    "flavour": "Vanilla bean · Garden florals",
    "description": "Two ivory tiers, hand-finished with a pearl border and a spray of garden florals. The studio will tailor the flowers, filling, and finish to your wedding.",
    "image": "floral-wedding",
    "alt": "A two-tier ivory wedding cake with peach garden roses",
    "categories": [
      "wedding"
    ],
    "badge": "Bespoke favourite",
    "cocoa": false,
    "variants": [
      [
        "2 kg",
        6500,
        "18–24 servings"
      ],
      [
        "3 kg",
        9200,
        "28–36 servings"
      ],
      [
        "4 kg",
        11900,
        "38–48 servings"
      ]
    ],
    "families": [
      "classic",
      "nuts"
    ],
    "layers": [
      "Vanilla bean tiers",
      "Customisable cream filling",
      "Ivory buttercream & garden florals"
    ],
    "tones": [
      "#debc8d",
      "#efe0d2",
      "#e3cdba"
    ],
    "edition": "signature",
    "folio": "06"
  },
  {
    "id": "daisy-bento",
    "name": "Little Daisy Bento",
    "flavour": "Vanilla · Strawberry",
    "description": "A tiny celebration tucked into its own little box. Lilac buttercream, hand-piped daisies, and a strawberry centre make this a lovely cake for two.",
    "image": "bento-bloom",
    "alt": "A small lilac bento cake decorated with buttercream daisies",
    "categories": [
      "bento",
      "anniversary"
    ],
    "badge": "Petite collection",
    "cocoa": false,
    "variants": [
      [
        "250 g",
        650,
        "1–2 servings"
      ],
      [
        "350 g",
        850,
        "2–3 servings"
      ]
    ],
    "families": [
      "fruit",
      "classic"
    ],
    "layers": [
      "Petite vanilla sponge",
      "Strawberry centre",
      "Lilac buttercream daisies"
    ],
    "tones": [
      "#d7bb8b",
      "#ce7380",
      "#b5a5cc"
    ],
    "edition": "signature",
    "folio": "07"
  },
  {
    "id": "rose-cupcakes",
    "name": "Rosebud Cupcakes",
    "flavour": "Vanilla · Rose buttercream",
    "description": "Little vanilla cakes with a soft swirl of rose-tinted buttercream. A thoughtful gift, a tea-time treat, or a sweet addition to a celebration table.",
    "image": "cupcake-posies",
    "alt": "Three rose and vanilla buttercream cupcakes",
    "categories": [
      "cupcake",
      "birthday"
    ],
    "badge": "",
    "cocoa": false,
    "variants": [
      [
        "Box of 4",
        640,
        "4 cupcakes"
      ],
      [
        "Box of 6",
        930,
        "6 cupcakes"
      ],
      [
        "Box of 12",
        1800,
        "12 cupcakes"
      ]
    ],
    "families": [
      "nuts",
      "classic"
    ],
    "layers": [
      "Little vanilla sponges",
      "Rose buttercream",
      "Piped rosettes & rose petals"
    ],
    "tones": [
      "#d2ac80",
      "#edc5bf",
      "#d598aa"
    ],
    "edition": "signature",
    "folio": "08"
  },
  {
    "id": "pistachio-rose",
    "name": "Pistachio Rose",
    "flavour": "Roasted pistachio · Rose cream",
    "description": "A tender pistachio sponge, fragrant rose cream, and a fine coat of pistachio buttercream. Crushed nuts and a few rose petals bring a little texture to the finish.",
    "image": "pistachio-rose",
    "alt": "Pale pistachio cake with ivory piping, rose petals and chopped pistachios",
    "categories": [
      "signature",
      "birthday",
      "anniversary"
    ],
    "variants": [
      [
        "½ kg",
        1550,
        "4–6 servings"
      ],
      [
        "1 kg",
        2850,
        "8–12 servings"
      ],
      [
        "1½ kg",
        4150,
        "12–18 servings"
      ]
    ],
    "badge": "The Kolkata edit",
    "cocoa": false,
    "families": [
      "nuts"
    ],
    "layers": [
      "Roasted pistachio sponge",
      "Rose-scented cream",
      "Pistachio crumb & rose petals"
    ],
    "tones": [
      "#b3af7b",
      "#e9c0c6",
      "#9aab72"
    ],
    "edition": "atelier-02",
    "folio": "09"
  },
  {
    "id": "kesar-rasmalai",
    "name": "Kesar Rasmalai",
    "flavour": "Saffron milk · Rasmalai",
    "description": "Soft milk sponge with a saffron soak, cardamom cream, and little pieces of rasmalai. A crown of mithai, fine saffron threads, and pistachio slivers finishes the cake.",
    "image": "kesar-rasmalai",
    "alt": "Saffron cream cake topped with golden rasmalai, saffron and pistachio",
    "categories": [
      "signature",
      "birthday",
      "anniversary"
    ],
    "variants": [
      [
        "½ kg",
        1350,
        "4–6 servings"
      ],
      [
        "1 kg",
        2450,
        "8–12 servings"
      ],
      [
        "1½ kg",
        3550,
        "12–18 servings"
      ]
    ],
    "badge": "The Kolkata edit",
    "cocoa": false,
    "families": [
      "nuts",
      "classic"
    ],
    "layers": [
      "Saffron-soaked milk sponge",
      "Cardamom & rasmalai cream",
      "Rasmalai, saffron & pistachio"
    ],
    "tones": [
      "#d7b660",
      "#f2dfab",
      "#dbbf73"
    ],
    "edition": "atelier-02",
    "folio": "10"
  },
  {
    "id": "midnight-forest",
    "name": "Midnight Black Forest",
    "flavour": "Dark cocoa · Cherry compote",
    "description": "Deep cocoa sponge meets a bright cherry centre and lightly whipped cream. Finished with chocolate curls and a circle of cherries, it’s a classic with a generous heart.",
    "image": "midnight-forest",
    "alt": "Dark Black Forest gâteau with chocolate shavings, Chantilly rosettes and cherries",
    "categories": [
      "signature",
      "birthday"
    ],
    "variants": [
      [
        "½ kg",
        1250,
        "4–6 servings"
      ],
      [
        "1 kg",
        2350,
        "8–12 servings"
      ],
      [
        "1½ kg",
        3350,
        "12–18 servings"
      ]
    ],
    "badge": "New bake",
    "cocoa": true,
    "families": [
      "chocolate",
      "fruit"
    ],
    "layers": [
      "Dark cocoa sponge",
      "Cherry compote & Chantilly",
      "Chocolate curls & cherries"
    ],
    "tones": [
      "#624337",
      "#a44155",
      "#e8d9c9"
    ],
    "edition": "atelier-02",
    "folio": "11"
  },
  {
    "id": "ruby-velvet",
    "name": "Ruby Velvet",
    "flavour": "Red velvet · Cream cheese",
    "description": "Ruby-red sponge, a gentle cocoa note, and soft cream cheese frosting. Fresh raspberries and a crescent of cream give each slice a bright, tangy finish.",
    "image": "ruby-velvet",
    "alt": "Ruby red velvet layers with ivory cream cheese, raspberries and piped cream",
    "categories": [
      "signature",
      "anniversary",
      "birthday"
    ],
    "variants": [
      [
        "½ kg",
        1350,
        "4–6 servings"
      ],
      [
        "1 kg",
        2450,
        "8–12 servings"
      ],
      [
        "1½ kg",
        3550,
        "12–18 servings"
      ]
    ],
    "badge": "New bake",
    "cocoa": true,
    "families": [
      "chocolate",
      "fruit"
    ],
    "layers": [
      "Red velvet sponge",
      "Cream cheese frosting",
      "Fresh raspberry crescent"
    ],
    "tones": [
      "#963a47",
      "#f0ddcf",
      "#c76e7b"
    ],
    "edition": "atelier-02",
    "folio": "12"
  },
  {
    "id": "lemon-silk",
    "name": "Lemon Silk",
    "flavour": "Lemon curd · Toasted meringue",
    "description": "A light lemon sponge layered with silky citrus curd. Toasted meringue petals, a twist of zest, and translucent candied lemon keep the finish fresh and bright.",
    "image": "lemon-silk",
    "alt": "Golden lemon cake with a ring of toasted meringue and candied lemon slices",
    "categories": [
      "signature",
      "birthday",
      "anniversary"
    ],
    "variants": [
      [
        "½ kg",
        1250,
        "4–6 servings"
      ],
      [
        "1 kg",
        2150,
        "8–12 servings"
      ],
      [
        "1½ kg",
        3150,
        "12–18 servings"
      ]
    ],
    "badge": "New bake",
    "cocoa": false,
    "families": [
      "fruit"
    ],
    "layers": [
      "Lemon-zest sponge",
      "Bright lemon curd",
      "Toasted meringue petals"
    ],
    "tones": [
      "#d9bf73",
      "#e4ca73",
      "#e7d9bf"
    ],
    "edition": "atelier-02",
    "folio": "13"
  },
  {
    "id": "silk-pearl-tiers",
    "name": "Silk & Pearl Tiers",
    "flavour": "Vanilla bean · Blush buttercream",
    "description": "Two quietly sculptural tiers in blush and ivory. Fine fluting, sugar pearls, and a soft sugar bow make a wedding centrepiece that the studio can tailor to your palette.",
    "image": "silk-pearl-tiers",
    "alt": "Blush and ivory two-tier wedding cake with a sculptural sugar bow and pearls",
    "categories": [
      "wedding"
    ],
    "variants": [
      [
        "2 kg",
        7200,
        "18–24 servings"
      ],
      [
        "3 kg",
        9900,
        "28–36 servings"
      ],
      [
        "4 kg",
        12800,
        "38–48 servings"
      ]
    ],
    "badge": "Wedding atelier",
    "cocoa": false,
    "families": [
      "classic"
    ],
    "layers": [
      "Vanilla bean tiers",
      "Studio-matched buttercream",
      "A sugar bow & edible pearls"
    ],
    "tones": [
      "#d9bb94",
      "#edc4c7",
      "#ecddcc"
    ],
    "edition": "atelier-02",
    "folio": "14"
  },
  {
    "id": "caramel-bento",
    "name": "Caramel Biscuit Bento",
    "flavour": "Spiced biscuit · Salted caramel",
    "description": "A little vanilla cake with salted caramel and biscuit cream, tucked into its own bento box. A caramel swirl and a crisp biscuit make it an especially lovely cake to share.",
    "image": "caramel-bento",
    "alt": "Small caramel bento cake in a cream gift box with spiced biscuit crumbs",
    "categories": [
      "bento",
      "anniversary"
    ],
    "variants": [
      [
        "250 g",
        690,
        "1–2 servings"
      ],
      [
        "350 g",
        890,
        "2–3 servings"
      ]
    ],
    "badge": "Petite collection",
    "cocoa": false,
    "families": [
      "classic"
    ],
    "layers": [
      "Petite vanilla sponge",
      "Salted caramel & biscuit cream",
      "Spiced biscuit crumble"
    ],
    "tones": [
      "#d9b493",
      "#bf8c5f",
      "#ceab80"
    ],
    "edition": "atelier-02",
    "folio": "15"
  },
  {
    "id": "cocoa-cupcakes",
    "name": "Cocoa Truffle Cupcakes",
    "flavour": "Dark ganache · Hazelnut",
    "description": "Individual chocolate sponges finished with a dark ganache swirl, a chocolate curl, and a little toasted hazelnut. Choose a box for gifting or a larger celebration table.",
    "image": "cocoa-cupcakes",
    "alt": "Three dark chocolate cupcakes with ganache rosettes, chocolate curls and hazelnuts",
    "categories": [
      "cupcake",
      "birthday"
    ],
    "variants": [
      [
        "Box of 4",
        720,
        "4 cupcakes"
      ],
      [
        "Box of 6",
        1050,
        "6 cupcakes"
      ],
      [
        "Box of 12",
        1980,
        "12 cupcakes"
      ]
    ],
    "badge": "New bake",
    "cocoa": true,
    "families": [
      "chocolate",
      "nuts"
    ],
    "layers": [
      "Individual cocoa sponges",
      "Dark truffle ganache",
      "Chocolate curls & hazelnuts"
    ],
    "tones": [
      "#714c36",
      "#986546",
      "#51372c"
    ],
    "edition": "atelier-02",
    "folio": "16"
  }
];
  const featured = [
  "pistachio-rose",
  "strawberry-chantilly",
  "chocolate-noir",
  "kesar-rasmalai",
  "cherry-ribbon",
  "midnight-forest",
  "ruby-velvet",
  "lemon-silk"
];
  const newBakes = [
  "pistachio-rose",
  "kesar-rasmalai",
  "midnight-forest",
  "ruby-velvet",
  "lemon-silk",
  "silk-pearl-tiers",
  "caramel-bento",
  "cocoa-cupcakes"
];
  const studio = {
  "name": "Kettle Petal®",
  "greeting": "Kettle Petal",
  "district": "Lake Town",
  "city": "Kolkata",
  "phone": "+91 98307 06787",
  "tel": "+919830706787",
  "whatsapp": "919830706787",
  "address": "P-235, Block B, Sreebhumi, Lake Town, Kolkata, South Dumdum, West Bengal 700089, India",
  "maps": "https://www.google.com/maps?cid=8837671370622990818",
  "instagram": "https://www.instagram.com/kettlepetalbyshaili/",
  "hours": [
    "Monday–Saturday: 11 am–7 pm",
    "Sunday: 9 am–5 pm"
  ],
  "rating": 4.9,
  "reviewCount": 258
};
  const families = [{id:'any',name:'Any flavour'},{id:'chocolate',name:'Chocolate'},{id:'fruit',name:'Fruit & citrus'},{id:'nuts',name:'Floral & nutty'},{id:'classic',name:'Vanilla & caramel'}];
  return {categories, products, featured, newBakes, studio, image, families};
})();

/* Enquiry-first design review. No newsletter records are collected by this static preview. */
window.ATELIER_PORTABLE = true;

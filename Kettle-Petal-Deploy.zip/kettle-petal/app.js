/* Atelier motion · progressive enhancement, with no animation-library dependency.
   The storefront is visible and usable before motion starts. Optional playback is
   user-initiated; reduced motion, background tabs and leaving the hero stop it. */
const CakeMotion = (() => {
  'use strict';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const small = matchMedia('(max-width: 600px)');
  const ease = 'cubic-bezier(.19,.75,.22,1)';
  const available = () => !preference.matches && !document.hidden && typeof Element.prototype.animate === 'function';
  const running = new Set(), pending = new Set(), seen = new WeakSet();
  let revealObserver, heroObserver, playButton, timer, progress, advance;
  let touring = false, automaticStep = false, photoRevision = 0, lastPanel = '', booted = false;
  const period = 7200;

  function animate(el, name, frames, options = {}) {
    if (!el || !available()) return null;
    // Restart just this effect, never another component's transition.
    for (const a of el.getAnimations()) if (a.id === 'cb-' + name) a.cancel();
    const a = el.animate(frames, {duration: 580, easing: ease, fill: 'backwards', ...options});
    a.id = 'cb-' + name;
    running.add(a);
    const release = () => running.delete(a);
    a.finished.then(release, release);
    return a;
  }
  function rise(el, name, distance, delay = 0, duration = 570) {
    return animate(el, name, [
      {opacity: .28, transform: `translate3d(0,${distance}px,0)`},
      {opacity: 1, transform: 'translate3d(0,0,0)'}
    ], {duration, delay});
  }
  function splitHeadline() {
    const h = $('#hero-title');
    if (!h || h.querySelector('.headline-ink')) return;
    const italic = h.querySelector('em');
    if (!italic) return;
    const normal = h.firstChild.textContent, accent = italic.textContent;
    const frag = document.createDocumentFragment();
    [normal, accent].forEach((text, i) => {
      const line = document.createElement('span'), ink = document.createElement(i ? 'em' : 'span');
      line.className = 'headline-line'; ink.className = 'headline-ink'; ink.textContent = text;
      line.append(ink); frag.append(line);
      if (!i) frag.append(document.createTextNode(' '));
    });
    h.replaceChildren(frag);
  }
  function heroEntrance(initial = false) {
    splitHeadline();
    if (!available()) return;
    const compact = small.matches;
    const factor = initial ? 1 : .77;
    animate($('.hero-eyebrow .short-rule'), 'eyebrow-rule', [{transform: 'scaleX(.06)'}, {transform: 'scaleX(1)'}], {duration: 620 * factor});
    rise($('#hero-kicker'), 'hero-kicker', 6, 0, 560 * factor);
    $$('#hero-title .headline-ink').forEach((el, i) => {
      animate(el, 'headline', [
        {opacity: .12, transform: `translate3d(0,${compact ? 15 : 24}px,0) rotate(.65deg)`},
        {opacity: 1, transform: 'translate3d(0,0,0) rotate(0deg)'}
      ], {duration: 800 * factor, delay: (35 + i * 100) * factor});
    });
    rise($('#hero-description'), 'hero-description', compact ? 6 : 10, 125 * factor, 700 * factor);
    $$('.hero-buttons .btn').forEach((el, i) => rise(el, 'hero-cta', 8, (180 + i * 50) * factor, 610 * factor));
    if (initial) {
      animate($('#hero-photo'), 'photo-settle', [{transform: `scale(${compact ? 1.023 : 1.046})`}, {transform: 'scale(1)'}], {duration: 1500});
      animate($('.hero-stamp'), 'stamp-settle', [{opacity: .25, transform: 'rotate(-3deg) scale(.90)'}, {opacity: .82, transform: 'rotate(15deg) scale(1)'}], {duration: 1050, delay: 120});
    }
    $$('.sugar-glint').forEach((el, i) => animate(el, 'sugar-glint', [
      {opacity: 0, transform: 'scale(.48) rotate(-9deg)', offset: 0},
      {opacity: .85, transform: 'scale(1) rotate(0deg)', offset: .38},
      {opacity: .58, transform: 'scale(.95) rotate(3deg)', offset: .60},
      {opacity: 0, transform: 'scale(.70) rotate(7deg)', offset: 1}
    ], {duration: 1400, delay: 260 + i * 245, easing: 'ease-in-out'}));
  }
  function changePhoto(src, alt, transition) {
    const photo = $('#hero-photo');
    if (!photo) return;
    photo.alt = alt;
    if (photo.getAttribute('src') === src) return;
    const version = ++photoRevision;
    const art = photo.parentElement;
    $$('.departing-cake', art).forEach(el => el.remove());
    let old = null;
    if (transition && available() && photo.complete && photo.naturalWidth) {
      old = document.createElement('img'); old.className = 'departing-cake';
      old.setAttribute('aria-hidden', 'true'); old.alt = ''; old.src = photo.currentSrc || photo.src;
      art.append(old);
    }
    photo.src = src;
    if (!old) return;
    const drop = () => old.remove();
    const reveal = () => {
      if (version !== photoRevision || !old.isConnected || !available()) { drop(); return; }
      animate(photo, 'photo-settle', [{transform: `scale(${small.matches ? 1.015 : 1.033})`}, {transform: 'scale(1)'}], {duration: 950});
      const fade = animate(old, 'photo-dissolve', [{opacity: 1}, {opacity: 0}], {duration: 590, easing: 'ease-in-out', fill: 'both'});
      if (fade) fade.finished.then(drop, drop); else drop();
    };
    if (photo.decode) photo.decode().then(reveal, drop);
    else if (photo.complete) reveal();
    else { photo.addEventListener('load', reveal, {once: true}); photo.addEventListener('error', drop, {once: true}); }
  }

  function revealItem(el) {
    if (el.matches('.product-card,.category-tile,.trust-item')) {
      const index = Array.prototype.indexOf.call(el.parentElement.children, el);
      const columns = el.matches('.category-tile') ? (small.matches ? 3 : 6) : el.matches('.product-card') ? (innerWidth <= 940 ? 2 : 4) : (innerWidth <= 760 ? 2 : 4);
      rise(el, 'stagger-in', small.matches ? 9 : 16, (index % columns) * (small.matches ? 43 : 62), 635);
    } else if (el.matches('.finder-spread')) {
      animate($('.finder-print img',el),'notebook-photo',[{transform:'scale(1.038)'},{transform:'scale(1)'}],{duration:970});
      $$('.piping-drawing path',el).forEach((path,i)=>animate(path,'finder-stitch',[{strokeDashoffset:'1'},{strokeDashoffset:'0'}],{duration:820,delay:i*180}));
      rise($('.plate-label',el),'plate-label',6,95,540);
    } else if (el.matches('.bespoke-banner')) {
      animate($('.bespoke-art img', el), 'bespoke-photo', [{transform: 'scale(1.035)'}, {transform: 'scale(1)'}], {duration: 1120});
      $$('.bespoke-copy > *', el).forEach((x,i) => rise(x,'bespoke-copy',10,i*48,600));
    } else rise(el, 'section-in', small.matches ? 8 : 13, 0, 650);
  }
  function watchSections() {
    if (!revealObserver || preference.matches) return;
    for (const old of pending) if (!old.isConnected) { revealObserver.unobserve(old); pending.delete(old); }
    $$('.trust-item,.center-heading,.category-tile,.section-heading,.product-card,.finder-spread,.bespoke-banner,.faq-intro,.faq-list').forEach(el => {
      if (!seen.has(el) && !pending.has(el)) { pending.add(el); revealObserver.observe(el); }
    });
  }
  function feedbackHeart(id, added) {
    if (!available()) return;
    const root = $('#panel').open ? $('#panel') : document;
    const b = $$('.favourite-btn', root).find(el => el.dataset.id === id);
    if (!b) return;
    animate($('.icon', b), 'heart-beat', [{transform:'scale(1)'},{transform:'scale(.80)',offset:.22},{transform:`scale(${added?1.25:1.05})`,offset:.56},{transform:'scale(1)'}], {duration:390,easing:'ease-out'});
    if (added) {
      const ring = document.createElement('span'); ring.className = 'saved-halo'; ring.setAttribute('aria-hidden','true'); b.append(ring);
      const a = animate(ring,'saved-halo',[{opacity:.65,transform:'scale(.82)'},{opacity:0,transform:'scale(1.43)'}],{duration:480,easing:'ease-out'});
      if(a)a.finished.then(()=>ring.remove(),()=>ring.remove()); else ring.remove();
    }
  }
  function bagAdded(lineId) {
    if (!available()) return;
    const row = $$('.bag-line').find(el => $('[data-line]',el)?.dataset.line === lineId);
    if (row) {
      const thumb = $('.bag-line-image', row), mark = document.createElement('span');
      mark.className='bag-confirm-mark'; mark.setAttribute('aria-hidden','true');
      mark.innerHTML='<svg viewBox="0 0 20 20"><path pathLength="1" d="m4.5 10.2 3.4 3.4 7.6-7.6"/></svg>';
      thumb.append(mark);
      animate($('.bag-line-image img',row),'cake-in-bag',[{transform:'scale(1.08)'},{transform:'scale(1)'}],{duration:530});
      animate($('path',mark),'confirmation-stitch',[{strokeDashoffset:1},{strokeDashoffset:0}],{duration:310,delay:130});
      const a=animate(mark,'bag-check',[{opacity:0,transform:'scale(.55)',offset:0},{opacity:1,transform:'scale(1.07)',offset:.18},{opacity:1,transform:'scale(1)',offset:.32},{opacity:1,transform:'scale(1)',offset:.8},{opacity:0,transform:'scale(.9)',offset:1}],{duration:1280,easing:'ease-out'});
      if(a)a.finished.then(()=>mark.remove(),()=>mark.remove()); else mark.remove();
    }
    animate($('.bag-count'),'bag-count',[{transform:'scale(.77)'},{transform:'scale(1.23)',offset:.48},{transform:'scale(1)'}],{duration:420,easing:'ease-out'});
    rise($('.bag-summary .summary-row strong'),'new-subtotal',5,30,360);
  }
  function matchPrinted(el) {
    $$('.match-card,.oversize',el).forEach((x,i)=>animate(x,'match-printed',[
      {opacity:.32,transform:`translate3d(0,${small.matches?6:10}px,0) rotate(-.35deg)`},
      {opacity:1,transform:'translate3d(0,0,0) rotate(0deg)'}],{duration:455,delay:i*68}));
    rise($('.match-tag',el),'shortlist-label',4,0,350);
  }
  function tastingOpened(el){
    $$('.note-rule',el).forEach((x,i)=>animate(x,'tasting-ribbon',[{transform:'scaleX(.05)'},{transform:'scaleX(1)'}],{duration:450,delay:i*65}));
  }
  function priceChanged(){rise($('#variant-price'),'price-settle',4,0,320);rise($('#variant-servings'),'portions-settle',3,40,310);}
  function panelEntered(name) {
    stopTour();
    if (name !== lastPanel) {
      const h = $('#panel-title'); rise(h,'dialog-title',5,0,300);
      if (name==='product') animate($('.detail-image img'),'detail-photo',[{transform:'scale(1.025)'},{transform:'scale(1)'}],{duration:660});
    }
    lastPanel=name;
  }

  function paintPlay() {
    if (!playButton) return;
    const label=touring?'Pause the cake collection':'Play the cake collection';
    playButton.setAttribute('aria-pressed',String(touring));playButton.setAttribute('aria-label',label);playButton.title=label;
    playButton.innerHTML=touring?'<svg viewBox="0 0 14 14" aria-hidden="true"><path d="M4 2.5v9m6-9v9" fill="none" stroke="currentColor" stroke-width="2.4"/></svg><span>Pause</span>':'<svg viewBox="0 0 14 14" aria-hidden="true"><path d="M3.8 2.3 11 7l-7.2 4.7Z" fill="currentColor"/></svg><span>Play</span>';
    playButton.hidden=preference.matches || typeof Element.prototype.animate!=='function';
    $('#slide-status')?.setAttribute('aria-live',touring?'off':'polite');
  }
  function stopTour() {
    clearTimeout(timer);timer=0;
    if (progress) { progress.cancel();progress=null; }
    if (!touring) return;
    touring=false;$('#home')?.classList.remove('tour-running');paintPlay();
  }
  function schedule() {
    clearTimeout(timer);if(progress)progress.cancel();
    const indicator=$('.slide-dots [aria-current="true"] .tour-ink');
    progress=animate(indicator,'tour-clock',[{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:period,easing:'linear',fill:'both'});
    timer=setTimeout(()=>{
      const box=$('#home').getBoundingClientRect();
      if (!touring||!available()||$('#panel').open||box.bottom<80||box.top>=innerHeight) {stopTour();return;}
      automaticStep=true;try{advance();}finally{automaticStep=false;}
      if(touring)schedule();
    },period);
  }
  function slideChanged(animateCopy) {
    if (!automaticStep) stopTour();
    if(animateCopy)heroEntrance(false); else splitHeadline();
  }
  function motionPreferenceChanged() {
    document.documentElement.dataset.cakeMotion=preference.matches?'reduced':'full';
    if(preference.matches){stopTour();for(const a of [...running])a.cancel();$$('.departing-cake').forEach(el=>el.remove());}
    paintPlay();if(!preference.matches)watchSections();
  }
  function boot(nextSlide) {
    if(booted)return;booted=true;advance=nextSlide;
    const hero=$('#home'),art=$('.hero-art');if(!hero||!art)return;
    for(let i=0;i<3;i++){
      const g=document.createElement('span');g.className='sugar-glint sugar-glint-'+i;g.setAttribute('aria-hidden','true');
      g.innerHTML='<svg viewBox="0 0 32 32"><path d="M15 2c1.1 8.2 3.9 11 12 12-8.1 1.1-10.9 3.9-12 12C14 17.9 11.2 15.1 3 14c8.2-1 11-3.8 12-12Z"/><path d="M26.5 21v7M23 24.5h7"/></svg>';art.append(g);
    }
    $$('.slide-dots button').forEach(b=>{const fill=document.createElement('i');fill.className='tour-ink';fill.setAttribute('aria-hidden','true');b.append(fill);});
    playButton=document.createElement('button');playButton.type='button';playButton.className='tour-toggle';playButton.setAttribute('aria-controls','home');$('.slide-progress').append(playButton);
    playButton.addEventListener('click',()=>{if(touring){stopTour();return;}if(!available())return;touring=true;hero.classList.add('tour-running');paintPlay();schedule();});
    hero.addEventListener('focusin',e=>{if(touring&&e.target!==playButton)stopTour();});
    document.addEventListener('visibilitychange',()=>{if(document.hidden)stopTour();});
    window.addEventListener('pagehide',stopTour);
    window.addEventListener('blur',stopTour);
    document.addEventListener('keydown',e=>{if(e.key==='Escape')stopTour();});
    if('IntersectionObserver' in window){
      revealObserver=new IntersectionObserver(entries=>{for(const entry of entries){if(!entry.isIntersecting)continue;const el=entry.target;revealObserver.unobserve(el);pending.delete(el);seen.add(el);revealItem(el);}}, {threshold:.08,rootMargin:'0px 0px -3px 0px'});
      heroObserver=new IntersectionObserver(entries=>{if(entries[0].intersectionRatio<.12)stopTour();},{threshold:[0,.12]});heroObserver.observe(hero);
    }
    if(preference.addEventListener)preference.addEventListener('change',motionPreferenceChanged);
    else preference.addListener(motionPreferenceChanged);
    motionPreferenceChanged();heroEntrance(true);
  }
  return {boot,changePhoto,slideChanged,watchSections,feedbackHeart,bagAdded,matchPrinted,tastingOpened,priceChanged,panelEntered,panelClosed:()=>{lastPanel='';}};
})();

(() => {
  'use strict';
  const {products,categories,image,studio,featured,newBakes,families} = window.ATELIER;
  const $ = (s,root=document) => root.querySelector(s);
  const $$ = (s,root=document) => [...root.querySelectorAll(s)];
  const esc = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon = (name,extra='') => `<svg class="icon ${extra}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const money = n => '₹' + new Intl.NumberFormat('en-IN').format(n);
  const byId = id => products.find(p=>p.id===id);
  const getCategory = id => categories.find(c=>c.id===id);
  const clamp = (n,min,max) => Math.max(min,Math.min(max,n));
  const key = 'kp.atelier.v1.';
  const mem = {};
  const read = (k,def) => {try{return JSON.parse(localStorage.getItem(key+k) ?? 'null') ?? def;}catch{return mem[k] ?? def;}};
  const save = (k,v) => {mem[k]=v;try{localStorage.setItem(key+k,JSON.stringify(v));}catch{/* private/preview browsing still works in memory */}};
  const arr = v => Array.isArray(v)?v:[];
  const getLineId = () => (globalThis.crypto?.randomUUID?.() || ('line-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8)));
  let saved = [...new Set(arr(read('saved',[])).filter(id=>byId(id)))];
  let bag = arr(read('bag',[])).filter(b=>b && byId(b.id) && Number.isInteger(b.variant) && byId(b.id).variants[b.variant] && Number.isInteger(b.qty) && b.qty>0).slice(0,80).map(b=>({line:getLineId(),id:b.id,variant:b.variant,qty:clamp(b.qty,1,20),sponge:b.sponge==='Eggless request'?'Eggless request':'Classic sponge',inscription:String(b.inscription||'').slice(0,45)}));
  let profile=read('profile',{}); if(!profile || typeof profile!=='object') profile={};
  let collection='featured', sort='featured', family='any', slide=0, view='', accountTab='saved', lastFocus=null, toastTimer=null, orderDraft={}, customDraft={}, message='', messageType='';
  const panel=$('#panel'), content=$('#panel-content'), toast=$('#toast');
  const shouldReduceMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
  const closeButton = `<button class="icon-btn panel-close" data-action="close" aria-label="Close dialog">${icon('x')}</button>`;
  const head=(over,title)=>`${closeButton}<header class="panel-head"><p class="eyebrow">${over}</p><h2 id="panel-title">${title}</h2></header>`;
  const countItems=()=>bag.reduce((n,l)=>n+l.qty,0);
  const subtotal=()=>bag.reduce((n,l)=>n+byId(l.id).variants[l.variant][1]*l.qty,0);
  function updateCounts(){
    $('.bag-count').textContent=countItems();$('.bag-btn').setAttribute('aria-label',`Open shopping bag, ${countItems()} ${countItems()===1?'item':'items'}`);$('.saved-dot').hidden=!saved.length;
    $$('.favourite-btn').forEach(b=>{const p=byId(b.dataset.id),yes=saved.includes(b.dataset.id);b.setAttribute('aria-pressed',String(yes));b.setAttribute('aria-label',`${yes?'Remove':'Save'} ${p.name} ${yes?'from':'to'} favourites`);});
  }
  function notify(text,actionLabel='',action=''){
    clearTimeout(toastTimer);(panel.open?panel:document.body).append(toast);toast.innerHTML=`${icon('check')}<span>${esc(text)}</span>${action?`<button data-action="${action}">${esc(actionLabel)}</button>`:''}`;toast.classList.add('show');toastTimer=setTimeout(()=>toast.classList.remove('show'),3600);
  }
  function closeDropdown(){ $('#cakes-menu').hidden=true;$('#cakes-menu-toggle').setAttribute('aria-expanded','false'); }
  function openPanel(name,html,kind=''){
    closeDropdown();toast.classList.remove('show');if(!panel.open)lastFocus=document.activeElement;
    panel.className='panel '+kind;view=name;panel.dataset.view=name;content.innerHTML=html;content.tabIndex=-1;
    if(!panel.open)panel.showModal();document.body.classList.add('modal-open');panel.scrollTop=0;
    const focusEl=$('[data-initial-focus]',content)||content;focusEl.focus({preventScroll:true});CakeMotion.panelEntered(name);
  }
  function closePanel(){if(panel.open)panel.close();}
  panel.addEventListener('close',()=>{if(panel.open)return;CakeMotion.panelClosed();view='';document.body.classList.remove('modal-open');document.body.append(toast);toast.classList.remove('show');if(lastFocus?.isConnected)lastFocus.focus({preventScroll:true});});
  panel.addEventListener('click',e=>{if(e.target!==panel)return;const r=panel.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closePanel();});
  function scrollToEl(selector){const el=$(selector);if(el)requestAnimationFrame(()=>el.scrollIntoView({behavior:shouldReduceMotion()?'instant':'smooth',block:'start'}));}
  function markNav(current){$$('.desktop-nav .nav-link').forEach(el=>el.classList.toggle('active', current==='home'?el.dataset.action==='home':current==='cakes'?el.id==='cakes-menu-toggle':current==='finder'?el.dataset.action==='finder':false));}
  const favouriteButton=p=>`<button class="favourite-btn" data-action="favourite" data-id="${p.id}" aria-pressed="${saved.includes(p.id)}" aria-label="${saved.includes(p.id)?'Remove':'Save'} ${p.name} ${saved.includes(p.id)?'from':'to'} favourites">${icon('heart')}</button>`;
  function card(p){return `<article class="product-card"><div class="product-visual"><button class="product-photo" data-action="product" data-id="${p.id}" aria-label="Explore ${p.name}"><img src="${image(p.image+'-card')}" alt="${p.alt}" loading="lazy" decoding="async" width="640" height="640"></button>${p.badge?`<span class="product-badge">${p.badge}</span>`:''}${favouriteButton(p)}</div><div class="product-info"><h3><button data-action="product" data-id="${p.id}">${p.name}</button></h3><p class="flavour-line">${p.flavour}</p><a class="studio-rating" href="${studio.maps}" target="_blank" rel="noopener noreferrer" title="The bakery’s overall Google Maps rating, not an individual cake rating">${icon('star')} <b>${studio.rating}</b> · Studio rating</a><div class="product-bottom"><div class="price-stack"><small>Guide from</small>${money(p.variants[0][1])}</div><button class="card-cta" data-action="product" data-id="${p.id}">Choose cake ${icon('plus')}</button></div></div></article>`;}
  function miniProduct(p){return `<button class="mini-product" data-action="product" data-id="${p.id}"><img src="${image(p.image+'-small')}" width="67" height="67" alt="${p.alt}" loading="lazy"><span class="mini-info"><span class="mini-title">${p.name}</span><span class="mini-sub">${p.flavour}</span><span class="mini-price">Guide from ${money(p.variants[0][1])}</span></span>${icon('right')}</button>`;}
  function renderCategories(){
    $('#category-grid').innerHTML=categories.map(c=>`<button class="category-tile" data-action="collection" data-id="${c.id}" aria-label="Browse ${c.name}"><span class="category-picture"><img src="${image(c.image)}" alt="${c.alt}" width="448" height="448" loading="lazy"></span><span class="category-label">${c.name}</span></button>`).join('');
    $('#cakes-menu').innerHTML=`<button class="menu-all" data-action="shop">Shop all ${products.length} cakes ${icon('arrow')}</button><button data-action="collection" data-id="new"><img src="${image('pistachio-rose-small')}" alt="" width="32" height="32">New bakes · ${newBakes.length}</button>`+categories.map(c=>`<button data-action="collection" data-id="${c.id}"><img src="${image(c.image)}" alt="" width="32" height="32">${c.name}</button>`).join('');
  }
  // The finder recommends one real SKU, never sums hypothetical slices or quotes a bespoke size.
  const occasions = {
    birthday: {label:'Birthday', brief:'Birthday', picks:['pistachio-rose','midnight-forest','birthday-wish','kesar-rasmalai']},
    anniversary: {label:'Anniversary',brief:'Anniversary',picks:['cherry-ribbon','ruby-velvet','pistachio-rose','caramel-bento']},
    wedding: {label:'Wedding',brief:'Wedding',picks:['silk-pearl-tiers','garden-vows']},
    gift: {label:'Gifting',brief:'A gift',picks:['caramel-bento','daisy-bento','cocoa-cupcakes','rose-cupcakes','kesar-rasmalai','pistachio-rose']},
    gathering: {label:'Just because',brief:'Something else',picks:['lemon-silk','kesar-rasmalai','strawberry-chantilly','cocoa-cupcakes']}
  };
  let lastMatch = null;
  function recommendations(occasion, guests) {
    const preference=occasions[occasion];
    if(!preference || !Number.isInteger(guests) || guests<1 || guests>1000)return [];
    const suitable=p=>occasion==='wedding'?p.categories.includes('wedding'):
      occasion==='birthday'?p.categories.includes('birthday')||(guests<=3&&p.categories.includes('bento')):
      occasion==='anniversary'?p.categories.includes('anniversary'):!p.categories.includes('wedding');
    const matches=[];
    for(const p of products.filter(suitable)) {
      for(const [variant,v] of p.variants.entries()) {
        const numbers=v[2].match(/\d+/g).map(Number), min=numbers[0], max=numbers[numbers.length-1];
        if(max<guests || min-guests>Math.max(1,Math.ceil(guests*.18)))continue;
        const pref=preference.picks.indexOf(p.id);
        matches.push({p,variant,over:Math.max(0,min-guests),rank:pref<0?100:pref,spare:max-guests});
        break;
      }
    }
    return matches.sort((a,b)=>a.over-b.over||a.rank-b.rank||a.spare-b.spare||a.p.folio.localeCompare(b.p.folio)).slice(0,3);
  }
  function updateStepper(){const el=$('#finder-guests'),q=el.valueAsNumber;$$('[data-action="guest-step"]').forEach(b=>b.disabled=Number.isFinite(q)&&(Number(b.dataset.dir)<0?q<=1:q>=1000));}
  function resetMatches(){lastMatch=null;$('#finder-results').hidden=true;$('#finder-results').replaceChildren();$('#finder-status').textContent='';updateStepper();}
  function stepGuests(dir){const el=$('#finder-guests'),q=Number.isFinite(el.valueAsNumber)?Math.round(el.valueAsNumber):0;el.value=String(clamp(q+dir,1,1000));resetMatches();}
  function showMatches(form){
    const d=new FormData(form),occ=occasions[d.get('occasion')],guests=Number(d.get('guests'));if(!occ||!Number.isInteger(guests)||guests<1||guests>1000)return;
    const arr=recommendations(d.get('occasion'),guests),el=$('#finder-results'),people=`${guests} ${guests===1?'guest':'guests'}`;
    lastMatch={occasion:occ.brief,guests};
    const heading=arr.length?'Your cake shortlist':'Let’s plan a custom size.';
    el.innerHTML=`<div class="match-head"><div><p class="eyebrow">The studio’s suggestion</p><h3 id="matches-title" tabindex="-1">${heading}</h3></div><span class="match-tag">${esc(occ.label)} <i aria-hidden="true">/</i> ${people}</span></div>` +
      (arr.length?`<div class="match-grid">${arr.map(({p,variant},i)=>{const v=p.variants[variant];return `<button class="match-card" data-action="product" data-id="${p.id}" data-variant="${variant}" aria-label="Choose ${esc(p.name)}, ${esc(v[0])}, ${esc(v[2])}, guide ${money(v[1])}"><img width="76" height="76" src="${image(p.image+'-small')}" alt=""><span class="match-info"><span class="match-rank">Selection ${String(i+1).padStart(2,'0')}</span><strong>${esc(p.name)}</strong><span>${esc(v[0])} · ${esc(v[2])}</span><b>Guide ${money(v[1])}</b></span>${icon('up-right')}</button>`;}).join('')}</div><div class="match-foot"><span>Serving estimates depend on how you slice the cake.</span><button class="text-link" data-action="finder-custom">Ask for a custom size ${icon('arrow')}</button></div>`:
      `<div class="oversize"><p>There isn’t a single listed size we’d recommend for this table. The studio can help plan the portions, tiers, and finish for ${people}.</p><button class="btn btn-secondary" data-action="finder-custom">Plan a bespoke cake ${icon('arrow')}</button></div>`);
    el.hidden=false;$('#finder-status').textContent=`${arr.length?arr.length+' suggested '+(arr.length===1?'design':'designs'):'Bespoke size suggested'} for ${esc(occ.label)}, ${people}.`;
    $('#matches-title').focus({preventScroll:true});if(el.getBoundingClientRect().bottom>innerHeight-20)scrollToEl('#finder-results');CakeMotion.matchPrinted(el);
  }
  function openFinder(){
    if(panel.open)closePanel();closeDropdown();
    try{const u=new URL(location.href);u.hash='cake-finder';history.replaceState(null,'',u);}catch{/* opaque preview origin */}
    markNav('finder');requestAnimationFrame(()=>{$('#finder-title').focus({preventScroll:true});scrollToEl('#cake-finder');});
  }
  function customFromMatch(){if(lastMatch)customDraft={...customDraft,occasion:lastMatch.occasion,guests:String(lastMatch.guests)};showCustom();}
  function tastingNotes(p){return `<details class="tasting-fold"><summary><span class="tone-strip" aria-hidden="true">${p.tones.map(c=>`<i style="background:${c}"></i>`).join('')}</span><span>Inside the cake</span>${icon('plus')}</summary><ol>${p.layers.map((layer,i)=>`<li><span class="note-rule" style="--note-tone:${p.tones[i]}" aria-hidden="true"></span><span class="layer-name">${['Sponge','Centre','Finish'][i]}</span><span>${esc(layer)}</span></li>`).join('')}</ol></details>`;}
  function renderProducts(){
    const full=collection!=='featured';let list=collection==='featured'?featured.map(byId):collection==='new'?newBakes.map(byId):collection==='all'?products.slice():products.filter(p=>p.categories.includes(collection));
    const baseCount=list.length;if(full&&family!=='any')list=list.filter(p=>p.families.includes(family));
    if(sort==='low')list.sort((a,b)=>a.variants[0][1]-b.variants[0][1]);if(sort==='high')list.sort((a,b)=>b.variants[0][1]-a.variants[0][1]);if(sort==='name')list.sort((a,b)=>a.name.localeCompare(b.name));
    $('#products-title').textContent=collection==='featured'?'Signature favourites':collection==='all'?'The cake collection':collection==='new'?'Fresh from the studio':getCategory(collection)?.name||'The cake collection';
    $('#counter-description').textContent=collection==='featured'?'Eight studio picks, from pistachio rose to deep chocolate.':collection==='new'?'Eight new designs, inspired by Kolkata celebrations.':`${baseCount} ${baseCount===1?'design':'designs'}, baked to order in Kolkata.`;
    $('#catalogue-tools').hidden=!full;$('#browse-all').innerHTML=full?`Signature edit ${icon('arrow')}`:`View all cakes ${icon('arrow')}`;$('#browse-all').dataset.action=full?'featured':'shop';
    $('#filter-pills').innerHTML=[{id:'all',name:'All cakes'},{id:'new',name:'New bakes · '+newBakes.length},...categories].map(c=>`<button class="filter-pill" data-action="collection" data-id="${c.id}" aria-pressed="${c.id===collection}">${c.name}</button>`).join('');
    $('#product-count').textContent=`${list.length} ${list.length===1?'cake':'cakes'}`;$('#sort-products').value=sort;$('#flavour-filter').value=family;$('#product-grid').innerHTML=list.length?list.map(card).join(''):`<div class="empty-flavours"><h3>No cakes match this pairing.</h3><p>Try every flavour in this collection, or ask about a bespoke design.</p><button class="btn btn-secondary" data-action="clear-flavour">Show every flavour ${icon('arrow')}</button></div>`;
    $$('.category-tile').forEach(b=>b.classList.toggle('selected',b.dataset.id===collection));updateCounts();CakeMotion.watchSections();
  }
  function selectCollection(id,doScroll=true){
    if(!['all','featured','new'].includes(id)&&!getCategory(id))id='all';collection=id;if(doScroll||id==='featured')family='any';if(id==='featured')sort='featured';closePanel();closeDropdown();renderProducts();markNav('cakes');
    try{const url=new URL(location.href);if(id==='featured')url.searchParams.delete('collection');else url.searchParams.set('collection',id);url.hash='cakes';history.replaceState(null,'',url);}catch{/* offline viewer */}
    if(doScroll){requestAnimationFrame(()=>$('#products-title').focus({preventScroll:true}));scrollToEl('#cakes');}else $(`#filter-pills [data-id="${id}"]`)?.focus({preventScroll:true});
  }
  function goHome(){closePanel();closeDropdown();collection='featured';sort='featured';family='any';setSlide(0,false);renderProducts();markNav('home');try{const url=new URL(location.href);url.searchParams.delete('collection');url.hash='';history.replaceState(null,'',url);}catch{}window.scrollTo({top:0,behavior:shouldReduceMotion()?'instant':'smooth'});}
  const slides=[
    {kicker:'The celebration collection',title:'A little joy,',em:'beautifully baked.',description:'Handcrafted cakes for the moments that matter.<br class="desktop-break"> Baked to order in Lake Town, Kolkata.',photo:'strawberry-hero',alt:'Berry-topped strawberry Chantilly cake on a fluted porcelain stand',note:'Strawberry Chantilly',button:'Shop our cakes',action:'shop'},
    {kicker:'The bespoke collection',title:'Your occasion,',em:'your masterpiece.',description:'From a favourite flower to the colour of your dress.<br class="desktop-break"> A celebration cake with your story in every detail.',photo:'bespoke-banner',alt:'Custom ivory cake with garden roses, a blush ribbon, and a design sketch',note:'The Floral Atelier',button:'Plan my custom cake',action:'custom'},
    {kicker:'The chocolate collection',title:'Deep chocolate,',em:'pure delight.',description:'Velvety ganache, dark chocolate curls, and a hazelnut finish.<br class="desktop-break"> Meet the cake for a true cocoa lover.',photo:'chocolate-truffle',alt:'Chocolate Noir cake topped with chocolate curls and golden hazelnuts',note:'Chocolate Noir',button:'Discover Chocolate Noir',action:'product',id:'chocolate-noir'},
    {kicker:'The Kolkata edit · New bakes',title:'Pistachio rose,',em:'petal by petal.',description:'Roasted pistachio sponge, soft rose cream, and a scattering of petals.<br class="desktop-break"> One of eight new designs at the cake counter.',photo:'pistachio-editorial',alt:'Pistachio and rose cake on a porcelain stand beside pink roses',note:'Pistachio Rose · Plate 09',button:'Meet Pistachio Rose',action:'product',id:'pistachio-rose'}
  ];
  function setSlide(n,announce=true){
    slide=(n+slides.length)%slides.length;const s=slides[slide];
    $('#hero-kicker').textContent=s.kicker;$('#hero-title').innerHTML=`${s.title}<br><em>${s.em}</em>`;
    $('#hero-description').innerHTML=s.description;CakeMotion.changePhoto(image(s.photo),s.alt,announce);$('#photo-note').textContent=s.note;
    const pb=$('#hero-primary');pb.innerHTML=s.button+' '+icon('arrow');pb.dataset.action=s.action;pb.dataset.id=s.id||'';
    const sb=$('.hero-buttons .btn-secondary');sb.innerHTML=slide===1?`Explore the cakes ${icon('arrow')}`:`${icon('whisk')} Design a cake`;
    sb.dataset.action=slide===1?'shop':'custom';$('#slide-number').textContent=String(slide+1).padStart(2,'0');
    $$('[data-slide]').forEach((b,i)=>{if(i===slide)b.setAttribute('aria-current','true');else b.removeAttribute('aria-current');});
    if(announce)$('#slide-status').textContent=`Collection ${slide+1} of ${slides.length}: ${s.kicker}`;
    CakeMotion.slideChanged(announce);
  }
  function showProduct(id,selected=0){const p=byId(id);if(!p)return;const no=p.folio;selected=Number(selected);if(!Number.isInteger(selected)||!p.variants[selected])selected=0;const chosen=p.variants[selected];
    openPanel('product',`${closeButton}<div class="detail-layout"><div class="detail-image"><figure class="detail-mount"><div class="detail-printline" aria-hidden="true"><span>Studio plates</span><span>${no} / ${products.length}</span></div><picture><source media="(min-width:601px)" srcset="${image(p.image+'-detail')}"><img src="${image(p.image+'-card')}" alt="${p.alt}" width="640" height="640"></picture><figcaption><span>${studio.district}, ${studio.city}</span>${icon('whisk')}</figcaption></figure>${favouriteButton(p)}</div><div class="detail-contents"><p class="eyebrow">The cake counter · N° ${no}</p><h2 id="panel-title">${p.name}</h2><p class="detail-flavour">${p.flavour}</p><p class="detail-description">${p.description}</p>${tastingNotes(p)}<form id="product-form" data-id="${p.id}"><fieldset class="plain-fieldset"><legend>Choose your size</legend><div class="field-radio-set">${p.variants.map((v,i)=>`<label class="radio-chip"><input type="radio" name="variant" value="${i}" ${i===selected?'checked':''}>${v[0]}</label>`).join('')}</div></fieldset><fieldset class="plain-fieldset"><legend>Sponge preference</legend><div class="field-radio-set"><label class="radio-chip"><input type="radio" name="sponge" value="Classic sponge" checked>Classic</label><label class="radio-chip"><input type="radio" name="sponge" value="Eggless request">Request eggless</label></div></fieldset><div class="field"><label for="inscription">A message on your cake <small>optional</small></label><input id="inscription" name="inscription" maxlength="45" placeholder="e.g. Happy birthday, Anika" autocomplete="off"></div><div class="detail-foot"><div class="detail-price-row"><div><small>Guide price</small><br><strong id="variant-price">${money(chosen[1])}</strong></div><small id="variant-servings">${chosen[2]}</small></div><button type="submit" class="btn btn-primary btn-block">${icon('bag')} Add to my bag</button><p class="muted-note">Design inspiration shown. The studio confirms the finish, ingredients, and final quote. Please share any allergies.</p></div></form></div></div>`,'wide');
  }
  function addToBag(form){
    const data=new FormData(form),p=byId(form.dataset.id),variant=Number(data.get('variant')),sponge=data.get('sponge'),inscription=String(data.get('inscription')||'').trim().slice(0,45);if(!p?.variants[variant])return;
    const match=bag.find(l=>l.id===p.id&&l.variant===variant&&l.sponge===sponge&&l.inscription===inscription);
    if(match&&match.qty>=20){notify('For more than 20 cakes, ask us about a bespoke order.');return;}
    if(match)match.qty++;else if(bag.length<80) bag.push({line:getLineId(),id:p.id,variant,sponge,inscription,qty:1});else{notify('Please send this order before adding more designs.');return;}
    save('bag',bag);updateCounts();showBag();CakeMotion.bagAdded(match?.line||bag[bag.length-1].line);notify(`${p.name} added to your bag`);
  }
  function favourite(id){if(!byId(id))return;const was=saved.includes(id);saved=was?saved.filter(i=>i!==id):[...saved,id];save('saved',saved);updateCounts();if(view==='account' && accountTab==='saved')renderAccountInner();CakeMotion.feedbackHeart(id,!was);notify(was?'Cake removed from favourites':'A little favourite, saved.',was?'':'View saved',was?'':'account');}
  function empty(iconName,title,copy,label='Explore the cakes',action='shop'){return `<div class="empty-state"><div class="empty-symbol">${icon(iconName)}</div><h3>${title}</h3><p>${copy}</p><button class="btn btn-secondary" data-action="${action}">${label} ${icon('arrow')}</button></div>`;}
  function showBag(){openPanel('bag',head('Your cake selection',`The cake bag <span style="font-size:.57em;color:var(--rose)">(${countItems()})</span>`)+`<div class="panel-body">${bag.length?`<div class="bag-lines">${bag.map(l=>{const p=byId(l.id),v=p.variants[l.variant];return `<article class="bag-line"><button class="bag-line-image" data-action="product" data-id="${p.id}" data-variant="${l.variant}" aria-label="View ${p.name}"><img src="${image(p.image+'-small')}" alt="${p.alt}"></button><div><h3><button data-action="product" data-id="${p.id}" data-variant="${l.variant}">${p.name}</button></h3><p class="mini-sub">${v[0]} · ${l.sponge==='Classic sponge'?'Classic':'Eggless requested'}${l.inscription?`<br>“${esc(l.inscription)}”`:''}</p><button class="icon-btn remove-line" data-action="remove-line" data-line="${l.line}" aria-label="Remove ${p.name} from bag">${icon('bin')}</button><div class="bag-line-controls"><div class="quantity-control"><button data-action="quantity" data-dir="-1" data-line="${l.line}" aria-label="Decrease quantity of ${p.name}" ${l.qty<=1?'disabled':''}>${icon('minus')}</button><span>${l.qty}</span><button data-action="quantity" data-dir="1" data-line="${l.line}" aria-label="Increase quantity of ${p.name}" ${l.qty>=20?'disabled':''}>${icon('plus')}</button></div><span class="line-price">${money(v[1]*l.qty)}</span></div></div></article>`;}).join('')}</div><div class="bag-summary"><div class="summary-row"><span>Estimated subtotal</span><strong>${money(subtotal())}</strong></div><p class="muted-note">Delivery and any custom finishes are quoted separately. No payment is taken here.</p><button class="btn btn-primary btn-block" data-action="checkout">Plan my order ${icon('arrow')}</button></div><button class="bag-continue" data-action="close">Keep exploring</button>`:empty('bag','A little room for something sweet.','Choose a cake, select your size, and find it waiting here.')}</div>`,'drawer');}
  function changeBag(line,delta,remove=false){const l=bag.find(x=>x.line===line);if(!l)return;if(remove)bag=bag.filter(x=>x.line!==line);else l.qty=clamp(l.qty+delta,1,20);save('bag',bag);updateCounts();showBag();if(remove)notify('Cake removed from your bag');else{const b=$(`[data-action="quantity"][data-dir="${delta}"][data-line="${line}"]`,content);if(b&&!b.disabled)b.focus({preventScroll:true});}}
  function showSearch(){openPanel('search',head('Find your next favourite','Search the cake counter')+`<div class="panel-body"><label class="search-box">${icon('search')}<input type="search" id="cake-search" aria-label="Search by cake, flavour or occasion" placeholder="A flavour, a cake, an occasion…" autocomplete="off" data-initial-focus></label><p id="search-label" class="list-label" role="status"></p><div id="search-results"></div></div>`,'drawer');renderSearch('');}
  function renderSearch(q){const clean=q.toLowerCase().trim();const terms=clean.split(/\s+/).filter(Boolean);const list=products.filter(p=>{const hay=[p.name,p.flavour,p.description,p.badge,...p.categories.map(c=>getCategory(c)?.name||'')].join(' ').toLowerCase();return terms.every(t=>hay.includes(t));});$('#search-label').textContent=clean?`${list.length} ${list.length===1?'cake':'cakes'} to discover`:'From the studio collection';$('#search-results').innerHTML=list.length?list.map(miniProduct).join(''):empty('search','A recipe still to be written.','Try “chocolate”, “birthday”, or “bento”, or let the studio design something just for you.','Design a custom cake','custom');}
  function showAccount(tab='saved'){accountTab=tab;openPanel('account',head('Your personal collection','My cake book')+`<div class="panel-body"><div class="tabs" aria-label="Cake book sections"><button data-action="account-tab" data-tab="saved" aria-pressed="true">Saved cakes</button><button data-action="account-tab" data-tab="details" aria-pressed="false">My details</button></div><div id="account-inner"></div></div>`,'drawer');renderAccountInner();}
  function renderAccountInner(){if(!$('#account-inner'))return;$$('[data-action="account-tab"]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.tab===accountTab)));$('#account-inner').innerHTML=accountTab==='saved'?saved.length?`<p class="list-label">${saved.length} saved ${saved.length===1?'favourite':'favourites'}</p>`+saved.map(id=>`<div class="saved-line">${miniProduct(byId(id))}<button class="icon-btn" data-action="favourite" data-id="${id}" aria-label="Remove ${byId(id).name} from favourites">${icon('x')}</button></div>`).join(''):`${empty('heart','Keep your favourites close.','Tap the heart on any cake to save it in your personal cake book.')}<p class="muted-note" style="text-align:center">Your cake book is saved on this device.</p>`:`<form id="profile-form" class="account-form"><p class="lede">Save your name for your next order brief. These details stay on this device; no account or password is needed.</p><div class="form-grid"><div class="field full"><label for="profile-name">Your name</label><input id="profile-name" name="name" autocomplete="given-name" value="${esc(profile.name||'')}" maxlength="70" required></div><div class="field full"><label for="profile-area">Usual delivery area <small>optional</small></label><input id="profile-area" name="area" autocomplete="address-level3" value="${esc(profile.area||'')}" placeholder="e.g. Lake Town, Kolkata" maxlength="100"></div><button class="btn btn-primary full" type="submit">Save on this device ${icon('check')}</button></div></form>${profile.name?'<button class="profile-clear" style="margin-top:16px" data-action="clear-profile">Remove my saved details</button>':''}`;}
  function dateMin(days=0){const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());const get=t=>+parts.find(v=>v.type===t).value;const d=new Date(Date.UTC(get('year'),get('month')-1,get('day')+days));return d.toISOString().slice(0,10);}
  function niceDate(s){return new Intl.DateTimeFormat('en-IN',{day:'numeric',month:'long',year:'numeric',timeZone:'Asia/Kolkata'}).format(new Date(s+'T12:00:00+05:30'));}
  function showCheckout(){if(!bag.length){showBag();return;}const d=orderDraft;
    openPanel('checkout',head('Order enquiry · No payment yet','Plan your cake order')+`<div class="panel-body"><div class="brief-recap"><span>${countItems()} ${countItems()===1?'item':'items'} · Guide subtotal</span><strong>${money(subtotal())}</strong></div><form id="checkout-form" class="form-grid"><div class="field full"><label for="order-name">Your name</label><input id="order-name" name="name" maxlength="70" autocomplete="given-name" placeholder="Who are we baking for?" required value="${esc(d.name||profile.name||'')}"></div><div class="field full"><label for="order-date">Celebration date</label><input id="order-date" name="date" type="date" min="${dateMin()}" required value="${esc(d.date||'')}"><small class="muted-note">Pre-order enquiry only. The studio will confirm your requested date.</small></div><fieldset class="plain-fieldset full"><legend>Getting your cake to you</legend><div class="field-radio-set"><label class="radio-chip"><input type="radio" name="fulfilment" value="Delivery" ${d.fulfilment!=='Studio pickup'?'checked':''}>Kolkata delivery</label><label class="radio-chip"><input type="radio" name="fulfilment" value="Studio pickup" ${d.fulfilment==='Studio pickup'?'checked':''}>Studio pickup</label></div></fieldset><div class="field full" id="order-area-field" ${d.fulfilment==='Studio pickup'?'hidden':''}><label for="order-area">Delivery neighbourhood or postcode</label><input id="order-area" name="area" maxlength="100" autocomplete="address-level3" placeholder="e.g. Lake Town, 700089" ${d.fulfilment!=='Studio pickup'?'required':''} value="${esc(d.area||profile.area||'')}"></div><div class="field full"><label for="order-notes">Anything else? <small>optional</small></label><textarea id="order-notes" name="notes" maxlength="600" rows="2" placeholder="Allergies, colour preferences, or a special detail…">${esc(d.notes||'')}</textarea></div><p class="form-note full">You’ll review your enquiry before sending it to the bakery on WhatsApp. Your date is only reserved once the studio confirms it.</p><button class="btn btn-primary full" type="submit">Review my order brief ${icon('arrow')}</button></form><button class="bag-continue" data-action="bag">Back to my bag</button></div>`,'drawer');
  }
  const options=(a,current)=>a.map(v=>`<option value="${esc(v)}" ${v===current?'selected':''}>${esc(v)}</option>`).join('');
  function showCustom(){const d=customDraft;openPanel('custom',`${closeButton}<header class="custom-cover"><img src="${image('bespoke-banner')}" alt="Garden roses on a bespoke ivory cake"><div><p class="eyebrow">The bespoke studio</p><h2 id="panel-title">Let’s dream up your cake.</h2></div></header><div class="panel-body"><p class="lede custom-intro">Tell us a little about your celebration. We’ll help you shape the flavours, size, and finishing touches.</p><form id="custom-form" class="form-grid"><div class="field"><label for="custom-occasion">The occasion</label><select id="custom-occasion" name="occasion" required>${options(['Birthday','Anniversary','Wedding','Baby shower','A gift','Something else'],d.occasion||'Birthday')}</select></div><div class="field"><label for="custom-date">Celebration date</label><input type="date" id="custom-date" name="date" required value="${esc(d.date||'')}" min="${dateMin()}"></div><div class="field"><label for="custom-guests">Number of guests</label><input type="number" id="custom-guests" name="guests" min="1" max="1000" required placeholder="e.g. 12" value="${esc(d.guests||'')}"></div><div class="field"><label for="custom-flavour">Flavour direction</label><select id="custom-flavour" name="flavour">${options(['Guide me','Vanilla & berries','Chocolate truffle','Butterscotch','Red velvet','Something else'],d.flavour||'Guide me')}</select></div><div class="field full"><label for="custom-vision">Your cake idea</label><textarea id="custom-vision" name="vision" rows="3" required minlength="5" maxlength="1000" placeholder="Think colours, flowers, a theme, or a detail that means something to you…">${esc(d.vision||'')}</textarea></div><div class="field full"><label for="custom-name">Your name</label><input id="custom-name" name="name" maxlength="70" autocomplete="given-name" placeholder="Your first name" required value="${esc(d.name||profile.name||'')}"></div><p class="muted-note full">For tiered or detailed designs, enquire early. The studio confirms the lead time. You can attach inspiration photos when you share your brief on WhatsApp.</p><button type="submit" class="btn btn-primary full">Review my design brief ${icon('arrow')}</button></form></div>`);}
  function showHandoff(type,text){messageType=type;message=text;const link=`https://wa.me/${studio.whatsapp}?text=${encodeURIComponent(text)}`;openPanel('handoff',head('Ready for the studio',type==='custom'?'Your bespoke cake brief':'Your cake order brief')+`<div class="panel-body"><p class="lede">One last look, then send your message on WhatsApp. The studio will confirm the details and prepare your final quote.</p><pre class="message-preview" id="message-preview">${esc(text)}</pre><div class="handoff-actions"><a class="btn btn-primary" href="${esc(link)}" target="_blank" rel="noopener noreferrer">${icon('chat')} Send on WhatsApp ${icon('up-right')}</a><button class="btn btn-secondary" data-action="copy-brief">${icon('copy')} Copy brief</button></div><p class="muted-note handoff-note">Nothing has been sent or paid for yet. Prefer to call? <a href="tel:${studio.tel}"><u>${studio.phone}</u></a>.</p><button class="bag-continue" data-action="edit-brief">Edit my brief</button></div>`);}
  function prepareOrder(form){const d=Object.fromEntries(new FormData(form));d.name=d.name.trim();d.area=(d.area||'').trim();if(!d.name){$('#order-name').setCustomValidity('Please enter your name.');$('#order-name').reportValidity();return;}if(d.fulfilment==='Delivery'&&!d.area){$('#order-area').setCustomValidity('Please enter a delivery area.');$('#order-area').reportValidity();return;}orderDraft=d;const lines=bag.map(l=>{const p=byId(l.id),v=p.variants[l.variant];return `${l.qty} × ${p.name} — ${v[0]}\n${l.sponge}${l.inscription?` · Inscription: “${l.inscription}”`:''}\nGuide: ${money(v[1]*l.qty)}`;});const msg=`Hello ${studio.greeting}! I’m ${d.name}. I’d like a quote for:\n\n${lines.join('\n\n')}\n\nEstimated subtotal: ${money(subtotal())}\nCelebration date: ${niceDate(d.date)}\n${d.fulfilment}${d.fulfilment==='Delivery'?': '+d.area:' at '+studio.district}${d.notes?.trim()?'\nNotes: '+d.notes.trim():''}\n\nPlease confirm availability, ingredients, and the final price${d.fulfilment==='Delivery'?' including delivery':''}.`;showHandoff('order',msg);}
  function prepareCustom(form){const d=Object.fromEntries(new FormData(form));d.name=d.name.trim();d.vision=d.vision.trim();if(!d.name||d.vision.length<5){const el=!d.name?$('#custom-name'):$('#custom-vision');el.setCustomValidity(!d.name?'Please enter your name.':'Please describe your idea in at least five characters.');el.reportValidity();return;}customDraft=d;showHandoff('custom',`Hello ${studio.greeting}! I’m ${d.name}, and I’d love to design a custom cake.\n\nOccasion: ${d.occasion}\nDate: ${niceDate(d.date)}\nGuests: ${d.guests}\nFlavour: ${d.flavour}\n\nMy idea: ${d.vision}\n\nPlease let me know what’s possible and share a quotation.`);}
  function showStory(){openPanel('story',`${closeButton}<img class="story-cover" src="${image('bespoke-banner')}" alt="A floral cake and the sketch that inspired its design"><div class="story-body"><p class="eyebrow line-kicker">Our story</p><h2 id="panel-title">A Lake Town kitchen.<br><em>A personal touch.</em></h2><p>Shaili began Kettle Petal in 2017. In her Lake Town studio, a cake starts with one detail: a flower from a bridal bouquet, a birthday wish, or a flavour someone always asks for.</p><p>We bake to order and finish each design by hand. Whether it’s a bento cake for two or tiers for a roomful of loved ones, the idea is the same: to make something that feels unmistakably yours.</p><button class="btn btn-primary" data-action="visit">Meet the studio ${icon('arrow')}</button></div>`);}
  function showVisit(){openPanel('visit',head('Lake Town · Kolkata','Visit our cake studio')+`<div class="panel-body"><div class="visit-item">${icon('pin')}<div><strong>${esc(studio.name)}</strong><p>${esc(studio.address)}</p><a class="studio-badge" href="${studio.maps}" rel="noopener noreferrer" target="_blank">${icon('star')} ${studio.rating} on Google Maps · ${studio.reviewCount} reviews ${icon('up-right')}</a></div></div><div class="visit-item">${icon('clock')}<div><strong>Studio hours</strong><p>${studio.hours.map(esc).join('<br>')}<br>Holiday hours may differ.</p></div></div><div class="visit-item">${icon('phone')}<div><strong>Talk to the bakery</strong><a href="tel:${studio.tel}">${studio.phone}</a></div></div><div class="visit-item">${icon('instagram')}<div><strong>From Shaili’s studio</strong><a href="${studio.instagram}" rel="noopener noreferrer" target="_blank">@kettlepetalbyshaili</a></div></div><div class="form-actions"><a class="btn btn-primary" href="${studio.maps}" target="_blank" rel="noopener noreferrer">Get directions ${icon('up-right')}</a><a class="btn btn-secondary" href="https://wa.me/${studio.whatsapp}" target="_blank" rel="noopener noreferrer">${icon('chat')} WhatsApp us</a></div><p class="visit-note">For a design consultation or cake pickup, confirm a time with the studio first.</p></div>`);}
  function showPrivacy(){const token=read('newsletterToken','');openPanel('privacy',head('Your preferences','A note on privacy')+`<div class="panel-body privacy-body"><h3>Your cake book</h3><p>Your favourites, bag, inscriptions, and any ordering details you choose to remember stay in this browser. We don’t use advertising cookies or third-party trackers.</p><h3>Sharing a cake brief</h3><p>Product and custom enquiries are prepared on your device. Selecting “Send on WhatsApp” opens WhatsApp with your brief. You decide whether to send it. WhatsApp and Google Maps have their own privacy policies.</p><h3>Letters from the bakery</h3><p>${window.ATELIER_PORTABLE?'This preview does not collect a mailing list. You can review a request and decide whether to send your email to the studio on WhatsApp. No message is sent automatically.':'When you subscribe, your email and consent date are stored on this website’s mailing list. They are used for studio updates, not sold. You can opt out using your unsubscribe link, or contact the studio to request removal.'}</p>${token?'<button class="btn btn-secondary" data-action="unsubscribe">Unsubscribe this address</button>':''}<h3>Contact</h3><p>For a privacy or order question, contact ${esc(studio.name)} at <a href="tel:${studio.tel}"><u>${studio.phone}</u></a> or visit the Lake Town studio.</p></div>`);}
  function showMenu(){openPanel('menu',head(studio.name+' · Kolkata','The cake studio')+`<div class="panel-body"><nav class="mobile-nav-list" aria-label="Mobile navigation">${[['home','Home'],['shop','Shop all cakes'],['finder','Cake finder'],['categories','Our collections'],['custom','Custom cakes'],['story','Our story'],['visit','Visit the studio'],['account','My cake book']].map(([a,t])=>`<button data-action="${a}">${t} ${icon('right')}</button>`).join('')}</nav><div class="mobile-studio"><span class="eyebrow">Made in Kolkata</span><p>${studio.district} · <a href="tel:${studio.tel}">${studio.phone}</a></p></div></div>`,'drawer nav-drawer');}
  async function subscribe(form){
    if(window.ATELIER_PORTABLE){
      const email=String(new FormData(form).get('email')||'').trim();
      const href=`https://wa.me/${studio.whatsapp}?text=${encodeURIComponent('Hello '+studio.greeting+'! I would like to subscribe to studio letters at '+email+'.')}`;
      openPanel('letter-request',head('Letters from the bakery','Your subscription request')+`<div class="panel-body"><p class="lede">This client preview does not store email addresses. You can ask the studio to add <strong>${esc(email)}</strong> to its mailing list when you are ready.</p><a class="btn btn-primary" style="margin-top:18px" href="${esc(href)}" target="_blank" rel="noopener noreferrer">${icon('chat')} Request on WhatsApp</a><p class="muted-note" style="margin-top:10px">No subscription has been submitted.</p></div>`);return;
    }
    const submit=$('button[type=submit]',form),status=$('#newsletter-status');if(submit.disabled)return;const d=new FormData(form);submit.disabled=true;status.textContent='Adding your email to the studio list…';try{const r=await fetch('/api/newsletter',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:String(d.get('email')).trim(),website:d.get('website')||'',consent:true}),signal:AbortSignal.timeout(12000)});const data=await r.json();if(!r.ok||!data.ok){status.textContent=data.error||'Could not subscribe. Please try again.';return;}if(data.token)save('newsletterToken',data.token);form.reset();status.innerHTML='Thank you — you’re on the studio list. <button data-action="privacy">Manage preferences</button>.';}catch(e){status.innerHTML=`The mailing list is unavailable right now. Please try again or <a href="https://wa.me/${studio.whatsapp}" target="_blank" rel="noopener noreferrer"><u>message the studio</u></a>.`;}finally{submit.disabled=false;}}
  async function unsubscribe(el){el.disabled=true;try{const r=await fetch('/api/unsubscribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:read('newsletterToken','')}),signal:AbortSignal.timeout(12000)});if(!r.ok)throw 0;save('newsletterToken','');showPrivacy();notify('Your newsletter subscription has been removed.');$('#newsletter-status').textContent='You have unsubscribed from studio letters.';}catch{el.disabled=false;notify('Please try again or contact the studio to unsubscribe.');}}
  const actions={home:goHome,shop:()=>selectCollection('all'),featured:()=>selectCollection('featured'),collection:el=>selectCollection(el.dataset.id,!el.classList.contains('filter-pill')),finder:openFinder,'guest-step':el=>stepGuests(Number(el.dataset.dir)),'finder-custom':customFromMatch,'clear-flavour':()=>{family='any';renderProducts();$('#flavour-filter').focus({preventScroll:true});},categories:()=>{closePanel();scrollToEl('#collections');},custom:showCustom,product:el=>showProduct(el.dataset.id,el.dataset.variant),favourite:el=>favourite(el.dataset.id),search:showSearch,account:()=>showAccount(),bag:showBag,checkout:showCheckout,story:showStory,visit:showVisit,menu:showMenu,close:closePanel,privacy:showPrivacy,'next-slide':()=>setSlide(slide+1),'prev-slide':()=>setSlide(slide-1),quantity:el=>changeBag(el.dataset.line,Number(el.dataset.dir)),'remove-line':el=>changeBag(el.dataset.line,0,true),'account-tab':el=>{accountTab=el.dataset.tab;renderAccountInner();},'clear-profile':()=>{profile={};save('profile',profile);renderAccountInner();notify('Saved ordering details removed.');},'edit-brief':()=>messageType==='custom'?showCustom():showCheckout(),'copy-brief':async()=>{try{await navigator.clipboard.writeText(message);notify('Cake brief copied.');}catch{const range=document.createRange();range.selectNodeContents($('#message-preview'));const selection=getSelection();selection.removeAllRanges();selection.addRange(range);notify('Brief selected. Use your device’s Copy command.');}},unsubscribe};
  document.addEventListener('click',e=>{const slideEl=e.target.closest('[data-slide]');if(slideEl){setSlide(Number(slideEl.dataset.slide));return;}const el=e.target.closest('[data-action]');if(el&&actions[el.dataset.action]){e.preventDefault();actions[el.dataset.action](el);return;}if(!e.target.closest('.nav-dropdown'))closeDropdown();});
  $('#cakes-menu-toggle').addEventListener('click',e=>{const was=$('#cakes-menu').hidden;$('#cakes-menu').hidden=!was;e.currentTarget.setAttribute('aria-expanded',String(was));});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#cakes-menu').hidden){closeDropdown();$('#cakes-menu-toggle').focus();}if(e.key==='ArrowDown'&&e.target===$('#cakes-menu-toggle')){e.preventDefault();$('#cakes-menu').hidden=false;$('#cakes-menu-toggle').setAttribute('aria-expanded','true');$('#cakes-menu button').focus();}});
  document.addEventListener('focusin',e=>{if(!e.target.closest('.nav-dropdown'))closeDropdown();});
  document.addEventListener('input',e=>{if(e.target.form?.id==='finder-form')resetMatches();if(e.target.id==='cake-search')renderSearch(e.target.value);if(typeof e.target.setCustomValidity==='function')e.target.setCustomValidity('');});
  document.addEventListener('toggle',e=>{if(e.target.matches?.('.tasting-fold[open]'))CakeMotion.tastingOpened(e.target);},true);
  document.addEventListener('change',e=>{if(e.target.form?.id==='finder-form')resetMatches();if(e.target.id==='flavour-filter'){family=e.target.value;renderProducts();}if(e.target.id==='sort-products'){sort=e.target.value;renderProducts();}if(e.target.name==='variant'&&$('#product-form')){const p=byId($('#product-form').dataset.id),v=p.variants[Number(e.target.value)];$('#variant-price').textContent=money(v[1]);$('#variant-servings').textContent=v[2];CakeMotion.priceChanged();}if(e.target.name==='fulfilment'){$('#order-area-field').hidden=e.target.value==='Studio pickup';$('#order-area').required=e.target.value==='Delivery';}});
  function applyForm(form){
    if(!form.reportValidity())return;
    if(form.id==='finder-form')showMatches(form);
    if(form.id==='product-form')addToBag(form);
    if(form.id==='custom-form')prepareCustom(form);
    if(form.id==='checkout-form')prepareOrder(form);
    if(form.id==='newsletter')subscribe(form);
    if(form.id==='profile-form'){
      const d=new FormData(form),name=String(d.get('name')||'').trim();
      if(!name){$('#profile-name').setCustomValidity('Please enter your name.');$('#profile-name').reportValidity();return;}
      profile={name,area:String(d.get('area')||'').trim()};save('profile',profile);renderAccountInner();notify('Your details are saved on this device.');
    }
  }
  document.addEventListener('submit',e=>{e.preventDefault();applyForm(e.target);});
  // Offline preview buttons perform only local state updates. No form is posted.
  if(window.ATELIER_PORTABLE)document.addEventListener('click',e=>{
    const b=e.target.closest('button[type="submit"]');
    if(b?.form){e.preventDefault();applyForm(b.form);}
  });
  const sticky=()=>$('#header').classList.toggle('scrolled',window.scrollY>32);window.addEventListener('scroll',sticky,{passive:true});sticky();
  $('#flavour-filter').innerHTML=families.map(f=>`<option value="${f.id}">${esc(f.name)}</option>`).join('');updateStepper();
  renderCategories();const requested=new URLSearchParams(location.search).get('collection');if(['all','new'].includes(requested)||getCategory(requested))collection=requested;renderProducts();if(requested)markNav('cakes');
  CakeMotion.boot(()=>setSlide(slide+1));
  if(location.hash==='#cakes')setTimeout(()=>scrollToEl('#cakes'),0);
  else if(location.hash==='#cake-finder'){markNav('finder');setTimeout(()=>scrollToEl('#cake-finder'),0);}
})();
